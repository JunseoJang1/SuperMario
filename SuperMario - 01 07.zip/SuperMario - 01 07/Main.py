import pygame

from pygame import draw
from pygame.color import Color
from pygame.sprite import Sprite
from pygame.surface import Surface

# Mario
from Mario import Player


# Blocks
from question_mark import Question
from cracked_brick import Cracked_Brick
from coin import Coin

# set
from const import *

q_list = ['platform-q.png', 'platform-q1.png', 'platform-q2.png', 'platform-q3.png']
s_list = ['mario1', 'mario2', 'mario3', 'mario4', 'mario5']
BLOCKRECT_LIST = [345, 327, 300, 277, 254]
strr = "280, 250, 220, 190, 160, 130"


vel = 1
jump = False
jumpCount = 0
jumpMax = 17

if __name__ == "__main__":

    ############# 초기 변수 설정 #############
    FPS = 30

    size = (400, 461)
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption("Super Mario Bros. 1")
     
    background_img_menu = pygame.image.load("Image File/Background Image/Mario_menu.png")
    background_img_game = pygame.image.load("Image File/Background Image/Mario_sky.png")
    background_img = background_img_menu

    # Mario Set
    Mario_direction = 1 # 1은 오른쪽, 2는 왼쪽을 의미함.
    Mario_dash = 0
    
    collided_block = 0
    collided_q1 = 0
    collided_qq = 0
    changeMario = 0

    rect_x = 0
    rect_xx = 0
    rect_xxx = 276

    kkk = 0
    collidedit = True

    cb_list = [300, 277, 254, 231, 208]
    cb_listy = [300, 277, 254, 231, 208]
    nextlevel = 0
    
    ############ 게임 안에 Sprites 설정 ##############
            
    cracked_brick_group = pygame.sprite.Group()
    Mario = Player()
    Mario.rect.x = 0
    Mario.rect.y = 280
    mario_group = pygame.sprite.Group()
    mario_group.add(Mario)

    tmp_rect_y = 166
    tmp_rect_x = 0

    for i in range (100):
        cb = Cracked_Brick()
        cb.rect.x = rect_x
        cb.rect.y = 316
        cracked_brick_group.add(cb)
        rect_x += 30

    for k in range (100):
        cb = Cracked_Brick()
        cb.rect.x = rect_xx
        cb.rect.y = 345
        cracked_brick_group.add(cb)
        rect_xx += 30
        
    for p in range(0):        
        tmp_rect_x = 0
        for l in range (p+1):
            cb = Cracked_Brick()
            cb.rect.x = tmp_rect_x
            cb.rect.y = tmp_rect_y
            cracked_brick_group.add(cb)
            tmp_rect_x += 30
        tmp_rect_y += 30

    qb = Question()
    qb.rect.x = 23*8
    qb.rect.y = 23*9.8
    question_block_group = pygame.sprite.Group()   
    question_block_group.add(qb)

    coin = Coin()
    coin.rect.x = 100
    coin.rect.y = 100
    coin_group = pygame.sprite.Group()   
    coin_group.add(coin)

    pygame.init()
    
    #####################################
    
    # 처음 게임 상태
    game_state = GAME_INIT
    size = (1000, 361)
    screen = pygame.display.set_mode(size)
          
    run = True
    clock = pygame.time.Clock()

    while run:
        ####### 사용자 입력 처리 #######

        # 좌표 관련
        AA = True
        old_recty = Mario.rect.y
        
        while AA:
            old_recty += 42
            print (old_recty)
            print ("Result : ", old_recty -= 280)

            if old_recty > 280:
                if Mario.rect.y != 280:
                    print("FAIL")
                    AA = False
                else:
                    print("!!!!!!!!!!!!!!!!!!!!")
                    AA = False
            elif old_recty == 280:
                print("!!!!!!!!!!!!!!!!!!!!")
                AA = False
        if Mario.rect.y > 280:
            Mario.rect.y = 280

        if Mario.rect.x <= -15:
            Mario.rect.x += 10

        ### GET_PRESSED ###
        keys = pygame.key.get_pressed()

        """ """
        print(Mario.direction)
        print(Mario.rect.y)
        if keys[pygame.K_RIGHT]:
            # direction change
            if Mario.direction == 0 or Mario.direction == 2: # IDLE -> RIGHT or LEFT -> RIGHT
                Mario.image_change("Image File/Mario Image/walkingR.png")
                Mario.direction = 1
                
            # dash
            if game_state >= 2:
                if Mario.rect.x != 0:
                    if Mario_dash == 1:
                        Mario.rect.x += 3
                    elif Mario_dash == 0:
                        Mario.rect.x += 2

                else:
                    Mario.rect.x += 2
                    
        if keys[pygame.K_LEFT]:
            # direction change
            if Mario.direction == 0 or Mario.direction == 1: # IDLE -> LEFT or RIGHT -> LEFT
                Mario.image_change("Image File/Mario Image/walkingL.png")
                Mario.direction = 2

            # dash
            if game_state >= 2:
                if Mario.rect.x != 0:
                    if Mario_dash == 1:
                        Mario.rect.x -= 2.8
                    elif Mario_dash == 0:
                        Mario.rect.x -= 2
                else:
                    Mario.rect.x += 2
        Mario.rect.centerx = (Mario.rect.centerx + (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * vel)
        """ """
        ### EVENT.GET ###
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_RETURN:
                    if game_state == GAME_INIT:
                        game_state = GAME_STAGE1
                        Mario.rect.x = 100
                        background_img = background_img_game
                        
                if not jump and event.key == pygame.K_SPACE:
                    jump = True
                    jumpCount = jumpMax

                if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
                    Mario.direction = 0
                    Mario.image_change("Image File/Mario Image/Mario Idle.png")
                
        if jump:
            Mario.rect.y -= jumpCount
            if jumpCount > -jumpMax:
                jumpCount -= 1

        ####### group update #######
                
        mario_group.update()
        question_block_group.update()

        if (game_state == GAME_STAGE1):

            """ """
            collided_cracked_brick = pygame.sprite.groupcollide(mario_group, cracked_brick_group, False, False)
            collided_question = pygame.sprite.groupcollide(mario_group, question_block_group, False, False)
            collided_coin = pygame.sprite.groupcollide(mario_group, coin_group, False, False)
            if collided_question or collided_cracked_brick or collided_coin:
                jump = 0
                jumpCount =- 1
                
                if collided_question:
                    collided_qq = 1  
                    qb.image_change("Image File/Block Image/platform-air.png")
                    
                elif collided_coin:
                    list(collided_coin.values())[0][0].rect
                    coin_group.remove(coin)
                    
            else:
                if not jump:
                    Mario.rect.y -= jumpCount
                    jumpCount -= 1
            """ """
            
        ####### 게임 상태 그리기 #######
        screen.blit(background_img, screen.get_rect())

        sf = pygame.font.SysFont("Super Mario Bros. 2.", 15)
        text = sf.render('Stones'
                             ,True, (255,255,255))
        screen.blit(text, (10, 10))
        
        if (game_state >= 2): # 게임이 시작된 경우
            mario_group.draw(screen)
            cracked_brick_group.draw(screen)
            question_block_group.draw(screen)
            coin_group.draw(screen)

            
        if collided_qq != 1:
            if (collided_q1 % 23) < 4:
                change_color = ('Image File/Block Image//' + q_list[collided_q1 % 4])
                qb.image_change(change_color)
                question_block_group.update()

        collided_q1 += 1
        collided_block += 1

        
        pygame.display.flip()

        clock.tick(FPS)

pygame.quit()
