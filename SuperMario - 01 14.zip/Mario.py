import pygame

from pygame import draw
from pygame.color import Color
from pygame.sprite import Sprite
from pygame.surface import Surface
import sys

class Player(Sprite):
    def __init__(self):
        self.direction = 0
        super().__init__()
        self.init_image_change()
        
    def init_image_change(self):
        self.img = pygame.image.load("Image File/Mario Image/Mario Idle.png")
        self.sprite_width = 40
        self.sprite_height = 42
        self.sprite_sheet = pygame.image.load("Image File/Mario Image/Mario Idle.png").convert()
        #self.sprite_sheet = pygame.transform.scale(self.img, (120,42))
        self.sprite_columns = 3
        self.current_frame = 0
        
        self.image = Surface((self.sprite_width, self.sprite_height))
 
        rect = (self.sprite_width*self.current_frame, 0,
                  self.sprite_width, self.sprite_height)

        self.image.blit(self.sprite_sheet, (0,0), rect)
        self.image.set_colorkey(Color(255, 255, 255))
        self.rect = self.image.get_rect()

        ## Mario 전용 변수 ##
        
        
    def image_change(self, img):
        self.img = pygame.image.load(img)
        self.sprite_width = 40
        self.sprite_height = 42
        self.sprite_sheet = pygame.image.load(img).convert()
        #self.sprite_sheet = pygame.transform.scale(self.img, (120,42))
        self.sprite_columns = 3
        self.current_frame = 0
        
        self.image = Surface((self.sprite_width, self.sprite_height))

        rect = (self.sprite_width*self.current_frame, 0,
                  self.sprite_width, self.sprite_height)

        self.image.blit(self.sprite_sheet, (0,0), rect)
        self.image.set_colorkey(Color(255, 255, 255))
        
    def update(self):
        if self.current_frame == self.sprite_columns -1:
            self.current_frame = 0
        else:
            self.current_frame += 1

        rect = (self.sprite_width*self.current_frame, 0,
                  self.sprite_width, self.sprite_height)
        self.image.blit(self.sprite_sheet, (0,0), rect)
        
